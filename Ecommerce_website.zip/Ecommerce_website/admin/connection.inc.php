<?php
session_start();
$con=mysqli_connect("localhost","root","password","database_name");
define('SERVER_PATH',$_SERVER['DOCUMENT_ROOT']. '/storage/ssd2/479/12975479/public_html/');
define('SITE_PATH', 'https://admin-das.000webhostapp.com/');

define('PRODUCT_IMAGE_SERVER_PATH',SERVER_PATH.'media/product/');
define('PRODUCT_IMAGE_SITE_PATH',SITE_PATH.'media/product/');
?>
